//Chase Moskowitz
package com.mycompany.chasemoskowitzproject3;


import java.util.Random;

public class Grid
{
    // class fields
    private int[][] gameBoard;
    private int currentRow;
    private int currentCol;

    //for random numbers
    Random randomNumbers = new Random();

    private final int MAX_ELEMENT_VALUE = 1000;

    
    /**
        no-arg constructor - creates a 10x10 grid and sets random location
    */
    public Grid() 
    {


        gameBoard = new int[10][10];

        currentCol = 0;
        currentRow = 0;

        populateBoard();

        jump();
    }

    /**
        constructor  - creates a grid (newGridSize x newGridSize) and
                       sets random location
        @param newGridSize is the value to set for the dimensions of the grid
    */
    public Grid(int newGridSize)
    {

        gameBoard = new int[newGridSize][newGridSize];

        currentCol = 0;
        currentRow = 0;

        populateBoard();

        jump();

    }

    /**
     * private method populateBoard to set locations to random value
     */
    private void populateBoard() 
    {

        int row, col;

        for (row = 0; row < getGridSize(); row++) 
        {
            for (col = 0; col < getGridSize(); col++) 
            {
                int randomValue = randomNumbers.nextInt(MAX_ELEMENT_VALUE);

                gameBoard[row][col] = randomValue;

            }

        }
    }

    /**
        The jump() method sets a random location
    */
    public void jump() 
    {
        currentRow = randomNumbers.nextInt(getGridSize());
        currentCol = randomNumbers.nextInt(getGridSize());

    }

    /**
        getCurrentRow method returns value in currentRow field
        @return value in currentRow field
    */
    public int getCurrentRow() 
    {
        return currentRow;
    }

   /**
        getCurrentCol method returns value in currentCol field
        @return value in currentCol field
    */
    public int getCurrentCol() 
    {
        return currentCol;
    }

    /**
        The getCurrentValue() method returns the value in the game board
        or grid at the current row and current columm field (cell)
        @return the value in the grid at the current row and column
    */
    public int getCurrentValue()
    {
        return gameBoard[currentRow][currentCol];
    }

    /**
        The goNorth() method decreases the value in the current row
    */
    public void goNorth()
    {
         // decrease row (north)
        currentRow--;
        
         // make sure not less than 0
        if (currentRow < 0) 
        {
            currentRow = 0;
        }
    }

     /**
        The goSouth() method increases the value in the current row
    */
    public void goSouth()
    {
         // increase row (south)
        currentRow++;
        
        // make sure not greater than length-1
        if (currentRow > (gameBoard.length - 1)) 
        {
            currentRow = gameBoard.length - 1;
        }

    }

   /**
        The goWest() method decreases the value in the current column
    */
    public void goWest() 
    {
         // decrease col (west)
        currentCol--;

        // make sure not less than 0
        if (currentCol < 0) 
        {
            currentCol = 0;
        }

    }

    /**
        The gatherDaisies() method decreases the current location
        in the grid by 80% and returns the value decremented
        @return value of 80% decrease in grid
        */
    public int gatherDaisies()
    {
        int daisiesGathered;
        int total = getCurrentValue();

        daisiesGathered = (int) (total * 80.0 / 100.0);

        gameBoard[currentRow][currentCol] = total - daisiesGathered;

        return daisiesGathered;
    }

    /**
        The goEast() method increases the value in the
        current column
    */
    public void goEast() 
    {
         // increase col (east)
        currentCol++;

        // make sure not greater than length-1
        if (currentCol > (gameBoard[0].length - 1)) 
        {
            currentCol = gameBoard[0].length - 1;
        }

    }

   /**
        The getGridSize() method returns the size of the grid
        @return the size of the grid or length of the array
    */
    public int getGridSize() {

        return gameBoard.length;

    }
    
    /**  
        The toString() method is used to return a String representing this Grid
        @return a String representing this Grid
    */
    public String toString()
    {

        String stringToReturn = "";
        int row, col;

        for (row = 0; row < gameBoard.length; row++)
        {
            for (col = 0; col < gameBoard.length; col++)
            {
                if (gameBoard[row][col] < 100)
                    stringToReturn = stringToReturn + " ";
                if (gameBoard[row][col] < 10)
                    stringToReturn = stringToReturn + " ";
                stringToReturn = stringToReturn + gameBoard[row][col] + " ";
            }
            stringToReturn = stringToReturn + "\n";
        }
        return stringToReturn;
    
    }

        

}




