//Chase Moskowitz
package com.mycompany.chasemoskowitzproject3;

import java.util.Scanner;

public class ChaseMoskowitzProject3 
{

    public static void main(String[] args)
    {
        int daisies=0;
        int totalDaisies = 0;
        String choice = null;
        int jumpCounter=0;
        int gatherCounter=0;
       
        Grid grid = new Grid();
        
        Scanner scanner = new Scanner(System.in);
        
        do {

            System.out.printf("\nYou are in Spot [%d, %d]\n",
                    grid.getCurrentRow(), grid.getCurrentCol());
            System.out.println("There are " + grid.getCurrentValue()
                    + " daisies located here");
            System.out.println("\nYou currently have a total of "
                    + totalDaisies + " daisies");
            System.out.print("What would you like to do? "
                    + "(G, J, N, S, E, W, M, Q):");
            choice = scanner.nextLine();

       
            if (choice.equalsIgnoreCase("G"))
            {
                gatherCounter ++;
                daisies = grid.gatherDaisies();

                totalDaisies += daisies;

                System.out.println("You just gathered " + daisies
                        + " daisies from this spot");
            } 
            
            else if (choice.equalsIgnoreCase("J"))
            {
                jumpCounter ++;
                
                grid.jump();

                System.out.printf("Jumped to [%d, %d]\n", grid.getCurrentRow(),
                        grid.getCurrentCol());
                
                

            } 
            
            else if (choice.equalsIgnoreCase("N"))
            {

                grid.goNorth();

            } 
            
            else if (choice.equalsIgnoreCase("S"))
            {

                grid.goSouth();

            } 
            
            else if (choice.equalsIgnoreCase("E"))
            {

                grid.goEast();

            } 
            
            else if (choice.equalsIgnoreCase("W")) 
            {

                grid.goWest();

            } 
            
            else if (choice.equalsIgnoreCase("M")) 
            {

                System.out.println("Map of Grid: \n" + grid);

            } 
            
            else if (choice.equalsIgnoreCase("Q")) 
            {

                System.out.printf("\nYou gathered a total of %,d daisies!",
                 totalDaisies);
          System.out.printf("\nYou did it in %d jumps and %d number "
                  + "of gatherings",jumpCounter, gatherCounter);

            } 
            
            else 
            {

                System.out.println("Invalid choice");

            }

        } 
        
        while (!choice.equalsIgnoreCase("Q"));
        
       

    }
}
    

